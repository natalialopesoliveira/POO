
public class Ponto {
	private float x,y;
	private float limiteSuperior, limiteInferior;
}
